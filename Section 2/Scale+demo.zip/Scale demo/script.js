var div = document.getElementById("box");
var scalex = document.getElementById("scalex");
scalex.addEventListener("change", scalexChange);
var scaley = document.getElementById("scaley");
scaley.addEventListener("change", scaleyChange);
var value1 = scalex.value;  
var value2 = scaley.value; 

function scalexChange() {
	value1 = scalex.value;
	div.style.transform = "scale(" + value1 + "," +value2 + ")";
  	document.getElementById('span1').innerHTML=value1;
}

function scaleyChange() {
	value2 = scaley.value;
	div.style.transform = "scale(" + value1 + "," +value2 + ")";
  	document.getElementById('span2').innerHTML=value2;
}
