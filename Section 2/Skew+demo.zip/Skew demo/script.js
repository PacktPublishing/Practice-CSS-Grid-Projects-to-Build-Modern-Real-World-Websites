var div = document.getElementById("box");
var skewx = document.getElementById("skewx");
skewx.addEventListener("change", skewxChange);
var skewy = document.getElementById("skewy");
skewy.addEventListener("change", skewyChange);
var value1 = skewx.value;  
var value2 = skewy.value; 

function skewxChange() {
	value1 = skewx.value;
	div.style.transform = "skew(" + value1 + "deg," +value2 + "deg)";
  	document.getElementById('span1').innerHTML=value1 + "deg";
}

function skewyChange() {
	value2 = skewy.value;
	div.style.transform = "skew(" + value1 + "deg," +value2 + "deg)";
  	document.getElementById('span2').innerHTML=value2 +"deg";
}
