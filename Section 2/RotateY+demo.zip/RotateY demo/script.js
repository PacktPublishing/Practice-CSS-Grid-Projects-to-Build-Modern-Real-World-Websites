var div = document.getElementById("box");
var rotateEl = document.getElementById("rotateEl");
rotateEl.addEventListener("change", rotateChange);
var value = rotateEl.value;  

function rotateChange() {
	value = rotateEl.value;
	div.style.transform = "rotateY(" + value + "deg)";
  	document.getElementById('span1').innerHTML=value + "deg";
}
